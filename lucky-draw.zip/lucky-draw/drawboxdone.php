<?php
if ( !defined('ABSPATH') ){
    die();
}  
if(wp_kses_post(wp_unslash(isset($_POST["Lucky_Draw_Nonce_Field"])))&&wp_verify_nonce(wp_kses_post(wp_unslash($_POST["Lucky_Draw_Nonce_Field"])),'Lucky_Draw_Nonce')){ 
}else{die;}


global $wpdb;
global $current_user;
      wp_get_current_user();


      $draw_name="[Contest Name]";
      $draw_date="[Draw Date]";
      $websitename=wp_kses_post(get_bloginfo( 'name' ));
      $partname=$current_user->display_name;

if(isset($_POST["a"])){
$contest_id=wp_kses_post(wp_unslash($_POST["a"])).'<br>';
}
if(isset($_POST["sendmail"])){
$sendmail=wp_kses_post(wp_unslash($_POST["sendmail"]));
}
if(isset($_POST["current_url"])){
    $current_url=wp_kses_post(wp_unslash($_POST["current_url"]));
    }
if(isset($_POST["drawname"])){
$drawname=wp_kses_post(wp_unslash($_POST["drawname"]));
}
if(isset($_POST["drawdate"])){
$drawdate=wp_kses_post(wp_unslash($_POST["drawdate"]));
}





$newdrawdb=$wpdb->prefix.'lucky_draw_contestants';
 $contestant_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE contest_id =%s AND contestants=%s ORDER BY id ASC ",$newdrawdb,$contest_id,$current_user->user_email)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
if($contestant_count==0){


      //Send Participation Mail
if($sendmail=="sendmail"){

      $to      = $current_user->user_email;
      $subject = $drawname." Participation Confirmation";
      $headers = "Content-type:text/html;charset=UTF-8" . "\r\n";
      

      $message='<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lucky Draw Participation Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            line-height: 1.6;
            background-color: #f9f9f9;
            margin: 0;
        }
        .email-container {
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
            max-width: 600px;
            margin: auto;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .email-header {
            text-align: center;
            padding-bottom: 20px;
        }
        .email-header h1 {
            color: #28a745;
            font-size: 24px;
        }
        .email-body {
            font-size: 16px;
            margin-bottom: 20px;
        }
        .email-body p {
            margin: 10px 0;
        }
        .footer {
            text-align: center;
            font-size: 14px;
            color: #777;
            margin-top: 20px;
        }
        .footer a {
            color: #007bff;
            text-decoration: none;
        }
        .button {
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-top: 15px;
        }
    </style>
</head>
<body>

    <div class="email-container">
        <div class="email-header">
            <h1>'.wp_kses_post($drawname).' <br>Participation Confirmation</h1>
        </div>
        <div class="email-body">
            <p>Dear <b>'.wp_kses_post($partname).'</b>,</p>
            <p>Thank you for participating in our Lucky Draw! We are excited to inform you that your entry has been successfully registered. You are now in the running to win amazing prizes!</p>
            <p>The lucky draw will take place on <b>'.wp_kses_post($drawdate).'</b> and the winners will be announced shortly after. Stay tuned, and we wish you the best of luck!</p>
        </div>
        <div class="footer">
            <p>Thank you for being part of this exciting event!<br>
            From '.$websitename.'</p>
        </div>
    </div>';


      // More headers
      $headers .= 'From: <'.$current_user->user_email.'>' . "\r\n";
      wp_mail($to, $subject, $message, $headers);
      


}
//  $result = $wpdb->insert($wpdb->prefix.'lucky_draw_contestants',array('contest_id'=>$contest_id,'contestants' => $current_user->user_email,'contestant_name' => $current_user->display_name)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
wp_redirect($current_url);
exit;

} 
