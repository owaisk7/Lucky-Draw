<?php 
if ( !defined('ABSPATH') ){
     die();
   }


   //Insert Draw When Submitted
   if(isset($_POST["Lucky_Draw_Submit"])){
    if(wp_kses_post(wp_unslash(isset($_POST["Lucky_Draw_Nonce_Field"])))&&wp_verify_nonce(wp_kses_post(wp_unslash($_POST["Lucky_Draw_Nonce_Field"])),'Lucky_Draw_Nonce')){ 
      include_once 'includes/putvalues.php';

  }else {  die; }
}

?>
<body class="">
  
<div class="row " style="width:100%;">
  

  <div class="col-8 p-4 ms-4 mt-5 pl-3 px-4 shadow p-1 mb-5 bg-dark-tertiary rounded" >
          
      
      <?php if(!isset($_GET['style'])&&!isset($_GET['prize'])){ include_once 'includes/draw-details.php'; } 

if(isset($_GET['prize'])&&!isset($_GET['style'])){ 
  

  include_once 'includes/lucky-draw-prizes.php';
}

if(isset($_GET['prize'])&&isset($_GET['style'])){ 
  

  include_once 'includes/draw-styling.php';
}

      ?>
      
  </div>
<!-- Left Column Ends -->




<!-- Right Column Page -->
  <div class="col-3 ms-4 mt-5 shadow  mb-5 bg-dark-tertiary rounded" style="min-height:135px;">
<?php 
// Add Draw Details Help Section When Style Or Prize is not clicked  
if(!isset($_GET['style'])&&!isset($_GET['prize'])){ include_once 'includes/draw-details-help.php'; } 

if(isset($_GET['prize'])&&!isset($_GET['style'])){ 
  

  include_once 'includes/draw-details-help.php';
}
if(isset($_GET['style'])){ include_once 'preview.php';   }
?>



</div>
