<?php 
if ( !defined('ABSPATH') ){
  die();
}
global $wpdb;
global $current_user;
      wp_get_current_user();

      function lucky_draw_get_product_link_by_sku($sku) {
        // Get the product by SKU
        $product = wc_get_product_id_by_sku($sku);
        
        if ($product) {
            // Get the product URL
            return get_permalink($product);
        } else {
            return false; // Return false if product not found
        }
      }
      
      $contestant_count=0;

      $result = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."lucky_draw  WHERE status =1  ORDER BY id DESC LIMIT 1 "); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange

foreach ($result as $post){

  $draw_id = $post->id;
  $draw_name = $post->draw_name;
  $draw_desc=$post->draw_desc;
  $draw_date=$post->draw_date;
  $prizes=$post->prizes;
  $sendmail=$post->sendmail;
  $stylebox=$post->box_style;

  

}
//Get Prizes And Replace Them
 $prizes=unserialize($prizes);

//Deserialixe Styles
 $stylebox=unserialize($stylebox);
 

if($prizes['displayas']=="Link"){
  $link= lucky_draw_get_product_link_by_sku("24-WB01");
$texttor='<b><a class="LinkPsreview" target="_blank" style=text-decoration:none;color:'.$stylebox['textlinkcolor'].'; href="'.$link.'" style="text-decoration:none;">'.$prizes['SKUText1'].'</a></b>';
}else{
  $texttor='<b>'.$prizes['SKUText1'].'</b>';
 
}
$draw_desc=str_replace("[prize1]",$texttor,$draw_desc);


$draw_desc=str_replace("[user]",'<b>'.$current_user->display_name.'</b>',$draw_desc);
$newdrawdb=$wpdb->prefix."lucky_draw_contestants";
if ( is_user_logged_in() ) {
 $contestant_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE contest_id =%s AND contestants=%s ORDER BY id ASC ",$newdrawdb,$draw_id,$current_user->user_email)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
}
if($contestant_count==0){
?>

<div id="drawpreview" class=" p-4 w-25 position-fixed bottom-0 end-0" style="z-index:999999999999999999" >
<input type="hidden" value="<?php echo esc_attr($draw_id); ?>">
<div id="PreviewBox" style="background-color:<?php echo wp_kses_post($stylebox['backgroundcolor']); ?>;border-color:<?php echo wp_kses_post($stylebox['bordercolor']); ?>;" class="alert  fade show" role="alert">
  <b><h5 class="alert-heading" id="Lucky_Draw_Name_Preview" style="color:<?php echo wp_kses_post($stylebox['titlecolor']); ?>;">
    <?php  // Contest Title
  echo wp_kses_post($draw_name);
  ?></h5></b>
   <hr>
    <p style="font-size:1em;color:<?php echo wp_kses_post($stylebox['descriptioncolor']); ?>;" class="mb-0" id="Lucky_Draw_Desc_Preview">
    <?php
    //Contest Desc
echo wp_kses_post($draw_desc).'<br>';
 ?> 
    <br><strong id="Draw_Date_Preview" style="<?php echo wp_kses_post($stylebox['drawdatecolor']); ?>;">Draw Date : <?php
   echo  wp_kses_post(wp_unslash($draw_date)); 
   ?></strong><hr>
      <div class="d-grid mt-2 gap-2 d-md-flex justify-content-md-end">
      <form  id="luckydrawboxform" method="POST" class="w-100" action="<?php echo wp_kses_post(admin_url('admin-post.php')); ?>" >
      <input type="hidden" name="action" value="lucky_draw_participation_form">
      <input id="mainvalue" type="hidden" value="<?php echo esc_attr($draw_id); ?>" name="a" >
      <input type="hidden" name="current_url" value="<?php echo esc_attr(get_permalink()); ?>"> 
      <input id="mainvalue" type="hidden" value="<?php echo esc_attr($sendmail); ?>" name="sendmail" >
      <?php wp_nonce_field( "Lucky_Draw_Nonce", "Lucky_Draw_Nonce_Field");  ?>

       <input id="mainvalue" type="hidden" value="<?php echo esc_attr($draw_name); ?>" name="drawname" >
       <input id="mainvalue" type="hidden" value="<?php echo esc_attr($draw_date); ?>" name="drawdate" >
 <?php if ( is_user_logged_in() ) { ?>
      <input  type="submit"  id="registerbutton" style="background-color:<?php echo wp_kses_post($stylebox['registerbuttoncolor']); ?>;color:<?php echo wp_kses_post($stylebox['registerbuttontext']); ?>;" value="Register Now" name="registernow">
  <?php  } else {
  ?>   <input type="submit" name="registernow"  id="registerbuttondisabled" style="background-color:<?php echo wp_kses_post($stylebox['registerbuttoncolor']); ?>;color:<?php echo wp_kses_post($stylebox['registerbuttontext']); ?>;" value="Login To Register">
   <?php }  ?>
      <input type="button"  id="closebutton" type="button" style="background-color:<?php echo wp_kses_post($stylebox['closebuttoncolor']); ?>;color:<?php echo wp_kses_post($stylebox['closebuttontext']); ?>" data-bs-dismiss="alert" aria-label="" value="Close">
    </form>
<!-- <button type="button" class="btn btn-primary w-30" data-bs-dismiss="alert" aria-label="">Close</button>
-->
    </div>


</div>
</div><?php }

