<?php

if ( !defined('ABSPATH') ){
  die();
}


global $wpdb;


?><div class="container container px-5 mt-5 w-75 ms-5 shadow p-1 mb-5 bg-dark-tertiary rounded"><?php
if(isset($_GET['_wpnonce'])){
  if ( wp_verify_nonce(wp_kses_post(wp_unslash($_GET['_wpnonce'])), 'URL_CHECK' )==1 ) {

  //Nonce Verified Via Url

    if(isset($_GET['id'])){
      //Delete Draw
     $fid=wp_kses_post(wp_unslash($_GET['id']));
    $wpdb->delete( $wpdb->prefix.'lucky_Draw', array( 'id' => $fid) );  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
    //db call ok; no-cache ok
      // Show Alert 
    ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Draw Successfully Deleted</strong><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php




    } 


  }
  else
  {
    die();
  }

}  
$nonce= wp_nonce_url( home_url().'/wp-admin/admin.php?page=lucky-draw','URL_CHECK');


$serialno=0;
$result = $wpdb->get_results( "SELECT * FROM wp_lucky_draw ORDER BY id ASC " ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange

?>
<table id="" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Sr</th>
                <th>Draw Name</th>
                <th>Draw Desc</th>
                <th>Status</th>

                <th>Draw Date</th>
                <th>Draw Prize</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
<?php



foreach ($result as $post){
  $serialno=$serialno+1;
echo '<tr>'; //Row Create 
echo '<td>'.wp_kses_post($serialno).'</td>';
$fsrno=wp_kses_post($srno = $post->id);
echo '<td>'.wp_kses_post($drawname = $post->draw_name).'</td>';
echo '<td>'.wp_kses( $drawdesc = $post->draw_desc,array('strong' => array(),)).'</td>';

echo '<td>';
if($drawstatus = $post->status==1){

echo '<span class="badge text-bg-primary">Active</span>';
}else{
  echo '<span class="badge text-bg-danger">Inactive</span>';
}


echo '</td>';
echo '<td>'.wp_kses_post($drawdate = $post->draw_date).'</td>';
$drawprize=$post->prizes;
$drawprize=unserialize($drawprize);
echo '<td>'.wp_kses_post($drawprize["SKU1"]).'  '.wp_kses_post($drawprize["SKU2"]).'  '.wp_kses_post($drawprize["SKU3"]).'</td>';


echo '<td><a href="'.wp_kses_post($nonce).'&id='.wp_kses_post($fsrno).'" class="link-underline-primary link-underline-opacity-0 link-underline-opacity-50-hover"><span class="badge text-bg-danger mt-1 ">Delete</span></a>';
} ?> 

        </tfoot>
    </table>
</div>
