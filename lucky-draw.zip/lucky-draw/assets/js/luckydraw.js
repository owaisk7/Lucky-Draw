$("#Lucky_Draw_Name").bind("change keyup", function(){
    var val = $(this).val();
    $("#Lucky_Draw_Name_Preview").html(val);
});

$("#Lucky_Draw_Desc").focusout(function(){
    var lddesc = $(this).val();
    lddesc=lddesc.replaceAll("[user]", "Username");
    lddesc=lddesc.replaceAll("{", "<strong>");
    lddesc=lddesc.replaceAll("}", "</strong>");
    $("#Lucky_Draw_Desc_Preview").html(lddesc);
});

$(document).ready( function () {
    $('#LuckyDrawTable').DataTable();
} );
	
$('table.display').DataTable();
//$('#drawdatepick').datepicker({

  
//  format: 'mm/dd/yyyy',
//  startDate: '-3d',
//  minDate: 0
//});

$(document).ready( function () {
  $('#myTable').DataTable();
} );

$("#drawdatepick").datepicker({
  startDate: '-3d',
  minDate: 0  
});

//$("#YesImInButton").click(function(){
//  alert("The paragraph was clicked.");
//});
  $('#registerbuttondisabled').click(function() {
      window.location.href = '../wp-login.php';
      return false;
  });



  $("#backgroundcolor").change(function(){
    $("#PreviewBox").css('background', $(this).val());
});
$("#titlecolor").change(function(){
    $("#Lucky_Draw_Name_Preview").css('color', $(this).val());
});

$("#descriptioncolor").change(function(){
    $("#Lucky_Draw_Desc_Preview").css('color', $(this).val());
});

$("#textlinkcolor").change(function(){
    $('#PreviewBox a').css('color', $(this).val());
});

$("#horizontallinecolor").change(function(){
    $('#PreviewBox hr').css('color', $(this).val());
});

$("#bordercolor").change(function(){
    $('#PreviewBox').css('border-color', $(this).val());
});

$("#drawdatecolor").change(function(){
    $('#Draw_Date_Preview').css('color', $(this).val());
});

$("#registerbuttoncolor").change(function(){
    $('#registerbutton').css('background-color', $(this).val());
});

$("#registerbuttontext").change(function(){
    $('#registerbutton').css('color', $(this).val());
});

$("#closebuttoncolor").change(function(){
    $('#closebutton').css('background-color', $(this).val());
});

$("#closebuttontext").change(function(){
    $('#closebutton').css('color', $(this).val());
}); 