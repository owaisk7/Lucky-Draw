<?php

if ( !defined('ABSPATH') ){
  die();
}


 global $wpdb;
 global $current_user;
      wp_get_current_user();

 $datetoday= gmdate('Y-m-d ', time());

?><div class="container px-5 mt-5 w-75 ms-5 shadow p-1 mb-5 bg-dark-tertiary rounded">
  <p class="fs-3">Draw Prize</p>
  
  <?php
if(isset($_GET['_wpnonce'])){
  if ( wp_verify_nonce(wp_kses_post(wp_unslash($_GET['_wpnonce'])), 'URL_CHECK' )==1 ) {
  //Nonce Verified Via Url

    if(isset($_GET['id'])){
      $contest_id=wp_kses_post(wp_unslash($_GET['id']));
      // get contestant and insert in array
      $luckydrawdb=$wpdb->prefix.'lucky_draw_contestants';
      $serialno=0;
      $const_email[0]=0;
      $const_name[0]='';
      $maindb=$wpdb->prefix.'lucky_draw';
      $drawname = $wpdb->get_var($wpdb->prepare("SELECT draw_name FROM %i WHERE id =%s ",$maindb,$contest_id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
      $prize = $wpdb->get_var($wpdb->prepare("SELECT prizes FROM %i WHERE id =%s ",$maindb,$contest_id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
$prize=unserialize($prize);
 
      $result = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
        $wpdb->prepare("SELECT contestants,contestant_name FROM %i WHERE contest_id = %d",$luckydrawdb,wp_kses_post(wp_unslash(($_GET['id'])))
            ));


        foreach ($result as $post){

        $serialno=$serialno+1;
        $contestnt = $post->contestants;
        $const_email[$serialno]=$contestnt;
        $const_name[$serialno]=$post->contestant_name;


      }
       $winno=wp_rand(1,$serialno);

       //Winner Name
        $winner_name=$const_name[$winno];
       //Winnr E-Mail
        $winner_mail=$const_email[$winno];
        
       //Set Contest ID To 0 i.e. InActive
      $wpdb->update($wpdb->prefix.'lucky_draw',array('status' => 0,'winner_email'=>$winner_mail,'winner_name'=>$winner_name),array('id'=>wp_kses_post(wp_unslash($_GET['id'])))); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange

        $to      = $current_user->user_email;
        $subject ="Congratulations! You Are a " .$drawname." Winner";
      
        ob_start();
        include_once ('includes/winnermail.php');
       $message= ob_get_clean();
        $headers = "Content-type:text/html;charset=UTF-8" . "\r\n";
        //Message For Email
        $message='<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Congratulations! You Are a Lucky Draw Winner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            line-height: 1.6;
            background-color: #f9f9f9;
            margin: 0;
        }
        .email-container {
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
            max-width: 600px;
            margin: auto;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .email-header {
            text-align: center;
            padding-bottom: 20px;
        }
        .email-header h1 {
            color: #28a745;
            font-size: 24px;
        }
        .email-body {
            font-size: 16px;
            margin-bottom: 20px;
        }
        .email-body p {
            margin: 10px 0;
        }
        .footer {
            text-align: center;
            font-size: 14px;
            color: #777;
            margin-top: 20px;
        }
        .footer a {
            color: #007bff;
            text-decoration: none;
        }
        .button {
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-top: 15px;
        }
    </style>
</head>
<body>

    <div class="email-container">
        <div class="email-header">
            <h1>Congratulations! You’ a Winner!</h1>
        </div>
        <div class="email-body">
            <p>Dear <strong>'.$winner_name.'</strong></p>
            <p>We are thrilled to announce that you are the winner of our Lucky Draw Contest !</p>
            <p>Your entry has been selected, and you’ve won <strong>'.wp_kses_post($prize["SKUText1"]).'</strong> We can’t wait for you to claim your prize.</p>  
            <p>If you have any questions or need assistance with claiming your prize, feel free to reach out to us at <strong>'.wp_kses_post($current_user->user_email).'</strong>.</p>
        </div>
        <div class="footer">
        </div>
    </div>

</body>
</html>';
        // More headers
        $headers .= 'From: <'.$current_user->user_email.'>' . "\r\n";
        wp_mail($to, $subject, $message, $headers);
        

//Delete Draw
     $fid=wp_kses_post(wp_unslash($_GET['id']));
      // Show Alert 
    ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      Contestant Name<strong> <?php echo wp_kses_post($winner_name); ?></strong> Has Won !!<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php




    } 


  }
  else
  {
    die();
  }

}  
$nonce= wp_nonce_url( home_url().'/wp-admin/admin.php?page=drawprize','URL_CHECK');


$serialno=0;
$luckydrawdb=$wpdb->prefix.'lucky_draw';
$result = $wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE draw_date <=%s AND status =1 ORDER BY id ASC ",$luckydrawdb,$datetoday));  // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange

?>
<table id="" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Sr.No</th>
                <th>Draw Name</th>
                <th>Status</th>
                <th>Total Applied</th>
                <th>Draw Date</th>
                <th>Draw Prize</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
<?php



foreach ($result as $post){
  $serialno=$serialno+1;
echo '<tr>'; //Row Create 
echo '<td>'.wp_kses_post($serialno).'</td>';
$fsrno=wp_kses_post($srno = $post->id);
echo '<td>'.wp_kses_post($drawname = $post->draw_name).'</td>';

echo '<td>';
if($drawstatus = $post->status==1){

echo '<span class="badge text-bg-primary">Active</span>';
}else{
  echo '<span class="badge text-bg-danger">Inactive</span>';
}

echo '</td>';
$drawdb=$wpdb->prefix."lucky_draw_contestants";
$comment_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE contest_id =%s ORDER BY id ASC ",$drawdb,$fsrno)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
echo '<td>' .wp_kses_post($comment_count ). '</td>';


echo '<td>'.wp_kses_post($drawdate = $post->draw_date).'</td>';
$drawprize=$post->prizes;
$drawprize=unserialize($drawprize);
echo '<td>'.wp_kses_post($drawprize["SKU1"]).'  '.wp_kses_post($drawprize["SKU2"]).'  '.wp_kses_post($drawprize["SKU3"]).'</td>';


echo '<td><a href="'.wp_kses_post($nonce).'&id='.wp_kses_post($fsrno).'" class="link-underline-primary link-underline-opacity-0 link-underline-opacity-50-hover"><span class="badge text-bg-danger mt-1 ">Draw Prize</span></a>';
} ?> 

        </tfoot>
    </table>
    </div>
