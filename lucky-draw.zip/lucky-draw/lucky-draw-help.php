<?php 
if ( !defined('ABSPATH') ){
    die();
  }
?>  
<div class="container mt-5 px-5 ">



<div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
      What is this Lucky Draw Plugin?
      </button>
    </h2>
        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
            <div class="accordion-body">
            <strong>The Lucky Draw Plugin</strong> allows users to participate in exciting prize draws on your WordPress website. Users can apply for a chance to win prizes, and the plugin automatically selects winners randomly.
            </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
      How does a user participate in the Lucky Draw?
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
      To participate in the Lucky Draw<br>

        1. User must be logged in.<br>
        2. User must click on the <strong>"Yes I'm In Button"</strong> in the contest box placed on the bottom right.<br>
        3. When the draw is complete user will recieve an email with the prize.<br>
        </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
      How are the winners selected?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
    
      Winners are selected randomly by the plugin, ensuring fairness. Each entry has an equal chance of winning, and the selection process is completely transparent and unbiased.<br>
      Administrator must manually complete the draw clicking the draw button 
    </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
      How does a user actually win the prize?
      </button>
    </h2>
    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
      If the user has won the draw they will recieve an email about it <br>
        Eg. If a user has won a contest with 50% Off on product with coupon code FLAT50OFF<br>
        Administrator must manually add the coupon FLAT50OFF in the Marketing ->Coupons sections
        and limit it to the user email.
        </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
      What Shotcode should be used to display Draw Box?
      </button>
    </h2>
    <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
      Shotcode <Strong>[lucky_draw_view]</Strong> Including [] symbols.
      Remeber : Only the lastest Draw eill be displayed.
        </div>
    </div>
  </div>

    </div>

