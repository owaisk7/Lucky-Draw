<?php
if ( !defined('ABSPATH') ){
  die();
}
global $wpdb;
if(wp_kses_post(wp_unslash(isset($_POST["Lucky_Draw_Nonce_Field"])))&&wp_verify_nonce(wp_kses_post(wp_unslash($_POST["Lucky_Draw_Nonce_Field"])),'Lucky_Draw_Nonce')){ 
}else {  die; }

if(isset($_POST["Lucky_Draw_Submit"])){ 
if(isset($_POST["Lucky_Draw_Name"])){ $draw_name=wp_kses_post(wp_unslash($_POST['Lucky_Draw_Name'])); }else{ $draw_name=''; }

if(isset($_POST["Lucky_Draw_Desc"])){ $draw_desc=wp_kses_post(wp_unslash($_POST['Lucky_Draw_Desc'])); }else{ $draw_desc=''; }

if(isset($_POST["Lucky_Draw_Date"])){ $draw_date=wp_kses_post(wp_unslash($_POST['Lucky_Draw_Date'])); }else{ $draw_date=''; }

if(isset($_POST["sendmail"])){ $sendmail=wp_kses_post(wp_unslash($_POST['sendmail'])); }else{ $sendmail=''; }

if(isset($_POST["winner_no"])){ $no_of_winners=wp_kses_post(wp_unslash($_POST['winner_no'])); }else{ $no_of_winners=''; }

if(isset($_POST["product_SKU_1"])){ $sku1=wp_kses_post(wp_unslash($_POST['product_SKU_1'])); }else{ $sku1=''; }

if(isset($_POST["product_SKU_2"])){ $sku2=wp_kses_post(wp_unslash($_POST['product_SKU_2'])); }else{ $sku2=''; }

if(isset($_POST["product_SKU_3"])){ $sku3=wp_kses_post(wp_unslash($_POST['product_SKU_3'])); }else{ $sku3=''; }

if(isset($_POST["prize_text_1"])){ $prizetext1=wp_kses_post(wp_unslash($_POST['prize_text_1'])); }else{ $prizetext1=''; }

if(isset($_POST["prize_text_2"])){ $prizetext2=wp_kses_post(wp_unslash($_POST['prize_text_2'])); }else{ $prizetext2=''; }

if(isset($_POST["prize_text_3"])){ $prizetext3=wp_kses_post(wp_unslash($_POST['prize_text_3'])); }else{ $prizetext3=''; }

if(isset($_POST["display_as"])){ $display_as=wp_kses_post(wp_unslash($_POST['display_as'])); }else{ $display_as=''; }

//Serialize Prize
$prize=array("SKU1"=>$sku1,"SKUText1"=>$prizetext1,"SKU2"=>$sku2,"SKUText2"=>$prizetext2,"SKU3"=>$sku3,"SKUText3"=>$prizetext3,"displayas"=>$display_as);
$prize=serialize($prize);
//Get Style Colors
if(isset($_POST["titlecolor"])){ $titlecolor=wp_kses_post(wp_unslash($_POST['titlecolor'])); }else{ $titlecolor=''; }

if(isset($_POST["backgroundcolor"])){ $backgroundcolor=wp_kses_post(wp_unslash($_POST['backgroundcolor'])); }else{ $backgroundcolor=''; }

if(isset($_POST["descriptioncolor"])){ $descriptioncolor=wp_kses_post(wp_unslash($_POST['descriptioncolor'])); }else{ $descriptioncolor=''; }

if(isset($_POST["textlinkcolor"])){ $textlinkcolor=wp_kses_post(wp_unslash($_POST['textlinkcolor'])); }else{ $textlinkcolor=''; }

if(isset($_POST["bordercolor"])){ $bordercolor=wp_kses_post(wp_unslash($_POST['bordercolor'])); }else{ $bordercolor=''; }

if(isset($_POST["drawdatecolor"])){ $drawdatecolor=wp_kses_post(wp_unslash($_POST['drawdatecolor'])); }else{ $drawdatecolor=''; }

if(isset($_POST["horizontallinecolor"])){ $horizontallinecolor=wp_kses_post(wp_unslash($_POST['horizontallinecolor'])); }else{ $horizontallinecolor=''; }

if(isset($_POST["registerbuttontext"])){ $registerbuttontext=wp_kses_post(wp_unslash($_POST['registerbuttontext'])); }else{ $registerbuttontext=''; }

if(isset($_POST["registerbuttoncolor"])){ $registerbuttoncolor=wp_kses_post(wp_unslash($_POST['registerbuttoncolor'])); }else{ $registerbuttoncolor=''; }

if(isset($_POST["closebuttoncolor"])){ $closebuttoncolor=wp_kses_post(wp_unslash($_POST['closebuttoncolor'])); }else{ $closebuttoncolor=''; }

if(isset($_POST["closebuttontext"])){ $closebuttontext=wp_kses_post(wp_unslash($_POST['closebuttontext'])); }else{ $closebuttontext=''; }


//Serialize Styles
$boxstyle=array("titlecolor"=>$titlecolor,"backgroundcolor"=>$backgroundcolor,"descriptioncolor"=>$descriptioncolor,"textlinkcolor"=>$textlinkcolor,"bordercolor"=>$bordercolor,"drawdatecolor"=>$drawdatecolor,"horizontallinecolor"=>$horizontallinecolor,"registerbuttoncolor"=>$registerbuttoncolor,"registerbuttontext"=>$registerbuttontext,"closebuttoncolor"=>$closebuttoncolor,"closebuttontext"=>$closebuttontext);
$boxstyle=serialize($boxstyle);
// Value 1 is Active and 0 Deactive For Status
$wpdb->insert($wpdb->prefix.'lucky_draw',array('draw_name' => $draw_name,'draw_desc' => $draw_desc,'status' => 1, 'draw_date'=> $draw_date,'sendmail'=>$sendmail,'no_of_winners'=>$no_of_winners,'prizes'=> $prize,'box_style'=> $boxstyle,)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange

?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  Contest Name <strong><?php echo wp_kses_post($draw_name); ?></strong> Successfully Added Use Shotcode <Strong>[lucky_draw_view]</Strong>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php } ?>