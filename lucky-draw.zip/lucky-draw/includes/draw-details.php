<?php

if ( !defined('ABSPATH') ){
  die();
}

global $wpdb;


  
  ?>
 <div class="ui ordered steps w-100">
  <div class="active step">
    <div class="content">
      <div class="title">Details</div>
      <div class="description">Enter Draw Details </div>
    </div>
  </div>
  <div class="disabled step">
    <div class="content">
      <div class="title">Prizes</div>
      <div class="description">Select Prizes</div>
    </div>
  </div>
  <div class="disabled step">
    <div class="content">
      <div class="title">Styling</div>
      <div class="description">Style Draw</div>
    </div>
  </div>
</div>
<form action="<?php echo wp_kses_post(Lucky_Draw_Home_URL).'admin.php?page=adddraw&prize=prize';  ?>" method="post" class="row">
    <div class="col-15 mt-3">
        <label for="validationServer01" class="form-label"> Draw Name</label>
        <input id="Lucky_Draw_Name" type="text" name="Lucky_Draw_Name" maxlength="41" class="form-control " id="validationServer01" value="" required>
        <div class="valid-feedback">
        </div>
    </div>






    <div class="col-15 mt-3">
        <label for="validationServer01" class="form-label">Draw Description</label>
        <textarea class="form-control" name="Lucky_Draw_Desc" maxlength="130" id="Lucky_Draw_Desc" rows="3" required></textarea>
    </div>    

    <div class="col-15 mt-3">
        <label for="validationServer01" class="form-label">Select Draw Date</label>
        <input id="drawdatepick" name="Lucky_Draw_Date" type="text" class="form-control" autocomplete="off" required>
        
    </div>
    <div class="col-12 mt-3">
    <div class="form-check">
      <input class="form-check-input mt-2" name="sendmail" type="checkbox" value="sendmail" id="invalidCheck" >
      <label class="form-check-label" for="invalidCheck">
        Send Participation Mail
      </label>
      
    </div>
  </div>

  <div class="col-15 mt-3">
        <label for="validationServer01" class="form-label"> No. Of Winners </label><br>
        
        <input type="radio" class="btn-check" name="winner_no" id="success-outlined" value="1" autocomplete="off" checked>
        <label class="btn btn-outline-primary" for="success-outlined">1</label>
        <input type="radio" class="btn-check" name="winner_no" id="danger-outlined" value="2" autocomplete="off">
        <label class="btn btn-outline-primary" for="danger-outlined">2</label>
        <input type="radio" class="btn-check" name="winner_no" id="primary-outlined" value="3" autocomplete="off">
        <label class="btn btn-outline-primary" for="primary-outlined">3</label>


    </div>
   
  <?php wp_nonce_field( "Lucky_Draw_Nonce", "Lucky_Draw_Nonce_Field");  ?>
    <div class="col-12 mt-4">
    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
      
  <button class="btn btn-primary me-md-2 px-4 " type="submit" name="Lucky_Draw_Details" > Next </button>
</div>  
  </div>
</form>
