<?php

if ( !defined('ABSPATH') ){
  die();
}

global $wpdb;
 if(isset($_POST["Lucky_Draw_Details"])){ 


  if(wp_kses_post(wp_unslash(isset($_POST["Lucky_Draw_Nonce_Field"])))&&wp_verify_nonce(wp_kses_post(wp_unslash($_POST["Lucky_Draw_Nonce_Field"])),'Lucky_Draw_Nonce')){ 
  }else {  die; }
  if(isset($_POST["Lucky_Draw_Name"])){ 
    $LD_name=wp_kses_post(wp_unslash($_POST['Lucky_Draw_Name']));
   

  } 

  if(isset($_POST["Lucky_Draw_Desc"])){ 
    $LD_desc=wp_kses_post(wp_unslash($_POST['Lucky_Draw_Desc']));
   

  } 

  if(isset($_POST["Lucky_Draw_Date"])){ 
    $LD_date=wp_kses_post(wp_unslash($_POST['Lucky_Draw_Date']));
    $LD_date = strtotime($LD_date);

    $LD_date= gmdate('Y-m-d',$LD_date);

  }

  if(isset($_POST["sendmail"])){ 
    $LD_mail='';

   $LD_mail=wp_kses_post(wp_unslash($_POST['sendmail']));
  }else{
    $LD_mail='';
  }


if(isset($_POST["winner_no"])){ 
    

   $winnerno =wp_kses_post(wp_unslash($_POST['winner_no']));
  }

  

?>
<!-- Success Alert -->
 

 <div class="ui ordered steps w-100">
  <div class="completed step">
    <div class="content">
      <div class="title">Details</div>
      <div class="description">Enter Draw Details </div>
    </div>
  </div>
  <div class="active step">
    <div class="content">
      <div class="title">Prizes</div>
      <div class="description">Select Prizes</div>
    </div>
  </div>
  <div class="disabled step">
    <div class="content">
      <div class="title">Styling</div>
      <div class="description">Style Draw</div>
    </div>
  </div>
</div>
<form action="<?php echo wp_kses_post(Lucky_Draw_Home_URL).'admin.php?page=adddraw&prize=prize&style=style';  ?>" method="post" class="row">
    <!-- No. Of Winners -->
<input type="hidden" name="Lucky_Draw_Name" value="<?php echo esc_attr($LD_name); ?>">
<input type="hidden" name="Lucky_Draw_Desc" value="<?php echo esc_attr($LD_desc); ?>">
<input type="hidden" name="Lucky_Draw_Date" value="<?php echo esc_attr($LD_date); ?>">
<input type="hidden" name="sendmail" value="<?php echo esc_attr($LD_mail); ?>">
<input type="hidden" name="winner_no" value="<?php echo esc_attr($winnerno); ?>">

<?php for($i=1;$i<=$winnerno;$i++){ ?>
<p class="fs-5 mt-3">Winner <?php echo wp_kses_post($i); ?></p>   

    <div id="SearchCol"class="col-15 ">
    <label for="validationServer01" class="form-label">Product <?php echo wp_kses_post($i); ?> SKU</label>
    <div class="ui search" id="product_SKU_<?php echo wp_kses_post($i); ?>">
    <input class="prompt form-control" name="product_SKU_<?php echo wp_kses_post($i); ?>" style="border-radius:none;" type="text" required>
  <div class="results"></div>
</div>
</div>
<div class="col-15 mt-3">
        <label for="validationServer01" class="form-label"> Link Text <?php echo wp_kses_post($i); ?></label>
        <input id="Lucky_Draw_Name" type="text" name="prize_text_<?php echo wp_kses_post($i); ?>" maxlength="15" class="form-control " id="validationServer01" value="" required>
        <div class="valid-feedback">
        </div>
    </div>
    <?php } ?>
  <div class="col-15 mt-3">
        <label for="validationServer01" class="form-label"> Display Prize As </label><br>
        
        <input type="radio" class="btn-check" name="display_as" id="success-outlined" value="Link" autocomplete="off" checked>
        <label class="btn btn-outline-primary" for="success-outlined">Link</label>
        <input type="radio" class="btn-check" name="display_as" id="danger-outlined" value="Text" autocomplete="off">
        <label class="btn btn-outline-primary" for="danger-outlined">Text</label>
  </div>

  
   
  <?php wp_nonce_field( "Lucky_Draw_Nonce", "Lucky_Draw_Nonce_Field");  ?>
    <div class="col-12 mt-4">
    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
      
  <button class="btn btn-primary me-md-2 px-4 " type="submit" name="Lucky_Draw_Styling" > Next </button>
</div>  
  </div>
</form>
<?php
}
  
// Get all the products
$products = lucky_draw_get_all_products_with_sku();

// Prepare the products array as JSON
$categoryContent = [];
foreach ($products as $product) {
    $categoryContent[] = [
        'category' => wp_kses_post($product['name']),
        'title' => wp_kses_post($product['sku']),
    ];
}

// Convert PHP array to JSON format
$categoryContentJson = wp_json_encode($categoryContent);

// Register a script handle

// Add inline script to the registered script handle
$inline_script = "
    var categoryContent = $categoryContentJson;
    $('#product_SKU_1').search({
        type: 'category',
        source: categoryContent
    });

    $('#product_SKU_2').search({
        type: 'category',
        source: categoryContent
    });

    $('#product_SKU_3').search({
        type: 'category',
        source: categoryContent
    });
";

// Add the inline script
wp_add_inline_script('luckydrawjs', $inline_script, 'after');

function lucky_draw_get_all_products_with_sku() {
    // Get all products
    $args = array(
        'post_type'      => 'product', // Post type for products
        'posts_per_page' => -1,        // Get all products
        'post_status'    => 'publish', // Only get published products
    );

    $query = new WP_Query($args);
    $products = $query->posts;

    $product_data = array();

    // Loop through each product
    foreach ($products as $product_post) {
        $product = wc_get_product($product_post->ID);
        
        // Get the product name and SKU
        $product_name = $product->get_name();
        $product_sku = $product->get_sku();

        // Add product data to array
        $product_data[] = array(
            'name' => $product_name,
            'sku'  => $product_sku,
        );
    }

    return $product_data;
}

// Usage example
