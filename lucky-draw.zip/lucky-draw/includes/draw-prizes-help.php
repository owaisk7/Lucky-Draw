<?php 
if ( !defined('ABSPATH') ){
    die();
  }
?>  
<div class="container p-0 mt-4 ">



<div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
      Can
      </button>
    </h2>
        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
            <div class="accordion-body">
            Draw Name is the name that will be displayed to users
            </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
      Can I Display User Name in description ?
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
      By using the code <Strong>[user]</Strong> including square brackets<br>
        If user is not Logged In then [user] will be ignored     
        </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
      How are the winners selected?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
    
      Winners are selected randomly by the plugin, ensuring fairness. Each entry has an equal chance of winning, and the selection process is completely transparent and unbiased.<br>
      Administrator must manually complete the draw clicking the draw button 
    </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
      How does a user actually win the prize?
      </button>
    </h2>
    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
      If the user has won the draw they will recieve an email about it <br>
        Eg. If a user has won a contest with 50% Off on product with coupon code FLAT50OFF<br>
        Administrator must manually add the coupon FLAT50OFF in the Marketing ->Coupons sections
        and limit it to the user email.
        </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
      What Shotcode should be used to display Draw Box?
      </button>
    </h2>
    <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
      Shotcode <Strong>[lucky_draw_view]</Strong> Including [] symbols.
      Remeber : Only the lastest Draw eill be displayed.
        </div>
    </div>
  </div>

    </div>

