<?php 
if ( !defined('ABSPATH') ){
  die();
}
if(wp_kses_post(wp_unslash(isset($_POST["Lucky_Draw_Nonce_Field"])))&&wp_verify_nonce(wp_kses_post(wp_unslash($_POST["Lucky_Draw_Nonce_Field"])),'Lucky_Draw_Nonce')){ 
 }else { die();  }
if(isset($_POST["Lucky_Draw_Styling"])){

function lucky_draw_get_product_link_by_sku($sku) {
  // Get the product by SKU
  $product = wc_get_product_id_by_sku($sku);
  
  if ($product) {
      // Get the product URL
      return get_permalink($product);
  } else {
      return false; // Return false if product not found
  }
}

//Get Values From All Forms

//Get SKU And Text
if(isset($_POST["product_SKU_1"])){ $prize1_SKU=wp_kses_post(wp_unslash($_POST['product_SKU_1']));}
if(isset($_POST["prize_text_1"])){ $prize1_text=wp_kses_post(wp_unslash($_POST['prize_text_1']));}
if(isset($_POST["Lucky_Draw_Desc"])){

 if(isset($_POST["display_as"])){
$display_as=wp_kses_post(wp_unslash($_POST["display_as"]));
 }

  $LD_Desc=wp_kses_post(wp_unslash($_POST["Lucky_Draw_Desc"]));
  if($display_as=="Link"){
     $link= lucky_draw_get_product_link_by_sku($prize1_SKU);
  $texttor='<b><a  class="LinkPsreview" href="'.$link.'" style="text-decoration:none;">'.$prize1_text.'</a></b>';
  }else{
     $texttor='<b>'.$prize1_text.'</b>';
    
  }

  $LD_Desc=str_replace("[prize1]",$texttor,$LD_desc);


}





?>
<div id="drawpreview" class="" >
      <div id="PreviewBox" class="alert  fade show" role="alert">
  <b><h5 class="alert-heading" id="Lucky_Draw_Name_Preview"><?php
  // Contest Title
  if(isset($_POST["Lucky_Draw_Name"])){ 
    $LD_name=wp_kses_post(wp_unslash($_POST['Lucky_Draw_Name']));
    echo wp_kses_post(wp_unslash($LD_name));
   } ?></h5></b>
   <hr>
    <p style="font-size:1em;" class="mb-0" id="Lucky_Draw_Desc_Preview">
    <?php
    //Contest Desc
echo wp_kses_post($LD_Desc).'<br>';
 ?> 
    <br><br><strong id="Draw_Date_Preview">Draw Date : <?php
  if(isset($_POST["Lucky_Draw_Date"])){ 
    $LD_date=wp_kses_post(wp_unslash($_POST['Lucky_Draw_Date']));
   echo  wp_kses_post(wp_unslash($LD_date));
   

  } ?></strong><hr>
      <div class="d-grid mt-2 gap-2 d-md-flex justify-content-md-end">

      <button id="registerbutton" class="btn btn-primary w-55 " type="button">Register Now</button>
      <button id="closebutton" type="button" class="btn btn-primary w-30" data-bs-dismiss="alert" aria-label="">Close</button>

<!-- <button type="button" class="btn btn-primary w-30" data-bs-dismiss="alert" aria-label="">Close</button>
-->
    </div>
</div>
<?php } ?>