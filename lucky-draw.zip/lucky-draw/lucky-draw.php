<?php
 if ( ! defined( 'ABSPATH' ) ) exit;
/**
Plugin Name: Lucky Draw 

Description: The Lucky Draw Plugin allows users to participate in exciting prize draws on your WordPress website. Users can apply for a chance to win prizes, and the plugin automatically selects winners randomly.
Version: 1.0.4
Author: Owais Khan
Author URI: https://github.com/owaisk7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

*/
global $wpdb;
define("Lucky_Draw_Plugin_URL",plugin_dir_url( __FILE__ ));
define("Lucky_Draw_Database", $wpdb->prefix.'lucky_draw');
define("Lucky_Draw_Home_URL", admin_url());





//Add Main Menu


add_action( 'admin_menu','lucky_draw_function');
function lucky_draw_function(){
  
//Add Menu
        add_menu_page('Lucky Draw Menu Page','Lucky Draw','manage_options','lucky-draw','lucky_draw_adminpage','dashicons-money-alt',15);
//Add Submenu
add_submenu_page('lucky-draw','Add Draw','Add Draw','manage_options','adddraw','lucky_draw_add_new_draw');

add_submenu_page('lucky-draw','Draw Prize ',' Draw Prize ','manage_options','drawprize','lucky_draw_the_prize');

add_submenu_page('lucky-draw','Email',' Email','manage_options','email','lucky_draw_email');

add_submenu_page('lucky-draw','Lucky Draw help','Lucky Draw Help ','manage_options','luckydrawhelp','lucky_draw_help');

}


add_shortcode( "lucky_draw_view", "lucky_draw_view");

function lucky_draw_view(){

ob_start();

  include (dirname(__FILE__).'../drawbox.php');
$html = ob_get_contents();
ob_get_clean();
return $html;

}


function lucky_draw_adminpage(){
        include (dirname(__FILE__).'../admin.php');


}

function lucky_draw_add_new_draw(){

        include_once (dirname(__FILE__).'../add-draw.php');

}
function lucky_draw_the_prize()
{
        include_once (dirname(__FILE__).'../draw-prize.php');

}

function lucky_draw_email(){

        include_once (dirname(__FILE__).'../email.php');

}


function lucky_draw_help(){

        include_once (dirname(__FILE__).'../lucky-draw-help.php');


}
function lucky_draw_participation_form() {
        if ( !defined('ABSPATH') ) {
                die('Direct access not allowed');
            }
            
        include_once 'drawboxdone.php';
      }
      
add_action('admin_post_lucky_draw_participation_form', 'lucky_draw_participation_form');

// Wp enqueue Scripts
function lucky_draw_assets(){
// Enqueue JS
 
 wp_enqueue_script('luckydrawjquerys','/wp-content/plugins/lucky-draw/assets/js/lucky_draw_jquery_3-7-1.js','','1.0',false);

 wp_enqueue_script('luckydrawjqueryui','/wp-content/plugins/lucky-draw/assets/js/lucky_draw_jqueryui.js','','1.0',false);

 wp_enqueue_script('luckydrawtablejs','/wp-content/plugins/lucky-draw/assets/js/lucky_draw_tables.js','','1.0',false);

// wp_enqueue_script('luckydrawsemanticjs','/wp-content/plugins/lucky-draw/assets/js/lucky_draw_semantic.min.js','','1.0',false);

 wp_enqueue_script('luckydrawbootstrap-bundle','/wp-content/plugins/lucky-draw/assets/js/lucky_draw_bootstrap533_bundle.js','','1.0 ',false);

 wp_enqueue_script('luckydrawsemanticsearchjs','/wp-content/plugins/lucky-draw/assets/js/search.min.js','','1.0 ',false);

 wp_enqueue_script('luckydrawjs','/wp-content/plugins/lucky-draw/assets/js/luckydraw.js','',' ',true);
 
// Enqueue CSS
wp_enqueue_style('luckydrawtables','/wp-content/plugins/lucky-draw/assets/css/lucky_draw_tables.css','','1.0');
 
wp_enqueue_style('luckydrawjquery-ui-css','/wp-content/plugins/lucky-draw/assets/css/lucky_draw_jquery_ui.css','','1.0');

wp_enqueue_style('luckydrawbootstrap','/wp-content/plugins/lucky-draw/assets/css/lucky_draw_bootstrap.css','','1.0');

wp_enqueue_style('luckydrawsemanticstep','/wp-content/plugins/lucky-draw/assets/css/lucky_draw_step.min.css','','1.0');


wp_enqueue_style('luckydrawbootstrapedit','/wp-content/plugins/lucky-draw/assets/css/lucky_draw_bootstrap_edit.css','','1.0');
 
wp_enqueue_style('luckydrawsemanticsearch','/wp-content/plugins/lucky-draw/assets/css/search.min.css','','1.0');

}
add_action( 'init',"lucky_draw_assets");


        include_once (dirname(__FILE__).'../includes/lucky-draw-db.php');







//Create Tables When Plugin Activated    
register_activation_hook(__FILE__,'lucky_draw_table_creation');
register_deactivation_hook(__FILE__,'lucky_draw_table_deletion');

